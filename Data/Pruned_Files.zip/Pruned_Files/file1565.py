from __future__ import division
import requests
from BeautifulSoup import BeautifulSoup

SETS_URL = 'http://sales.starcitygames.com/singlecategories.php'

BLACKLIST = ('Magic Wholesale')

def sets():
  with open('sets.txt', 'r') as f:
    s = f.read().split('\n')

  return s

def scg_sets():
  soup = BeautifulSoup(requests.get(SETS_URL).content)
  
  s = sets()

  return set([(item.string, item['href']) for item in soup.findAll('a') if str(item.string) in s and str(item['href']).find('t=a') == -1])

def get_pages(set_url='http://sales.starcitygames.com//category.php?t=a&cat=5061'):
  """Given a starting set page, this function will return URLs for every page for the set"""
  soup = BeautifulSoup(requests.get(set_url).content)

  return set([str(url['href']) for url in soup.findAll('a') if str(url.string).find('[') > -1 and str(url.string).find(']') > -1])

def card_pages(set_page):
  """Finds individual card pages for every card on a set page"""
  soup = BeautifulSoup(requests.get(set_page).content)

  pages = soup.findAll('a', attrs={'class':'card_popup'})

  return [(str(page)[str(page).find('>\n\t\t\t\t') + 6:-4], page['href'][page['href'].find('=') + 1:]) for page in pages]

  #return [(page.string, page['href'][page['href'].find('=') + 1:]) for page in pages]

def sets_to_file():
  """Grabs all the sets from scg and spits them to a text file"""
  soup = BeautifulSoup(requests.get('http://sales.starcitygames.com/singlecategories.php').content)

  with open('base_set_list.txt', 'r') as f:
    base_sets = [s[:-1] for s in f.readlines()]

  with open('set_list.txt', 'w') as f:
    for div in soup.findAll('div', align='center'):
      child = div.findChildren()[0]

      if child.string in base_sets:
        f.write(','.join([child.string, child['href']]) + '\n')
      elif child.string.find('(Foil)') == -1:
        print(child.string)

def set_urls_from_file(fname='set_list.txt'):
  
  with open(fname, 'r') as f:
    lines = f.readlines()

  return [line.split(',') for line in lines]

def cards_to_file():
  sets = set_urls_from_file()
  i = 0

  with open('cards.txt', 'w') as f:
    for s in sets:
      cur_set = s[0]
      set_url = s[1]
      
      print('Processing {}, {:.2%} complete'.format(cur_set, i / len(sets) ))
      i += 1

      for page in get_pages(set_url):
        cards = card_pages(page)

        for card in cards:
          f.write(';'.join([card[0], cur_set, card[1]]) + '\n')
    

if __name__ == '__main__':
  #sets_to_file()
  #print len(get_sets())

  cards_to_file()

  #print set_urls_from_file()

  #for page in get_pages():

    #cards.extend(card_pages(page))

  #print cards

#  print len(sets())

#  print len(scg_sets())

#  for s, u in scg_sets():
#    print s, u
